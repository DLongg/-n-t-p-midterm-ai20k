# 📚 TỔNG HỢP NGÂN HÀNG CÂU HỎI 15 NGÀY VLEARN (PHÂN CHIA ~20 CÂU/FILE)

Thư mục này được tạo tự động nhằm phục vụ nhu cầu:
1. **Nhập (Import) trực tiếp vào các nền tảng thi trắc nghiệm:** https://quiz.com/, Quizizz, Kahoot, Wayground, Google Forms,...
2. **Chia nhỏ mỗi ngày thành các phần trên dưới 20 câu hỏi:** Thời lượng làm bài lý tưởng từ 10 - 15 phút/lần, vừa vặn cho buổi học hoặc tự ôn luyện.
3. **Tự động chấm điểm 100%:** Toàn bộ câu hỏi ghép cặp (matching), quy trình (ordering) và tính toán số (numeric) đã được chuẩn hóa sang định dạng trắc nghiệm 4-5 lựa chọn với mã đáp án chuẩn xác.

---

## 📁 CẤU TRÚC THƯ MỤC TỔNG HỢP

```
TONG_HOP_QUIZ_15_NGAY_EXCEL/
│
├── 01_CHUAN_IMPORT_QUIZIZZ_QUIZ_COM_904_CAU/  <--- [DÙNG ĐỂ IMPORT VÀO QUIZ.COM / QUIZIZZ]
│   ├── Day_01_Foundation_LLM/
│   │   ├── Day_01_Phan_01_21_Cau.xlsx
│   │   ├── Day_01_Phan_02_20_Cau.xlsx
│   │   ├── Day_01_Phan_03_20_Cau.xlsx
│   │   ├── Day_01_Phan_04_20_Cau.xlsx
│   │   ├── Day_01_Phan_05_20_Cau.xlsx
│   │   └── Day_01_FULL_TOAN_BO_101_CAU.xlsx
│   ├── Day_02_AI_Product_Lab/ (2 file phần + 1 file Full)
│   ├── Day_03_Chatbot_vs_ReAct_Agent/ (2 file phần + 1 file Full)
│   ├── ...
│   └── Day_15_Trien_khai_thuc_te/ (3 file phần + 1 file Full)
│
└── 02_FULL_NGAN_HANG_1679_CAU_CHI_TIET_CHIA_20_CAU/  <--- [DÙNG ĐỂ XEM ĐẦY ĐỦ CẢ TỰ LUẬN & CODE]
    ├── Day_01_Full_150_Cau/ (8 file chia nhỏ ~20 câu)
    ├── Day_02_Full_121_Cau/ (6 file chia nhỏ ~20 câu)
    ├── ...
    └── Day_15_Full_122_Cau/ (6 file chia nhỏ ~20 câu)
```

---

## 🎯 DANH SÁCH 45 FILE IMPORT CHUẨN QUIZ.COM / QUIZIZZ (904 CÂU TRẮC NGHIỆM)

| Ngày | Chủ Đề Khóa Học | Tổng Câu | Số File (~20 câu) | Chi Tiết Số Câu Từng File | File Full Ngày |
| :---: | :--- | :---: | :---: | :--- | :--- |
| **Day 01** | Giới thiệu & Foundation LLM | **101 câu** | 5 files | P1: 21c, P2: 20c, P3: 20c, P4: 20c, P5: 20c | `Day_01_FULL_TOAN_BO_101_CAU.xlsx` |
| **Day 02** | AI Product Lab & Business Framing | **35 câu** | 2 files | P1: 18c, P2: 17c | `Day_02_FULL_TOAN_BO_35_CAU.xlsx` |
| **Day 03** | Chatbot vs ReAct Agent | **32 câu** | 2 files | P1: 16c, P2: 16c | `Day_03_FULL_TOAN_BO_32_CAU.xlsx` |
| **Day 04** | System Prompt Engineering & Tool Calling Engine | **58 câu** | 3 files | P1: 20c, P2: 19c, P3: 19c | `Day_04_FULL_TOAN_BO_58_CAU.xlsx` |
| **Day 05** | AI Product Thinking & Requirements | **40 câu** | 2 files | P1: 20c, P2: 20c | `Day_05_FULL_TOAN_BO_40_CAU.xlsx` |
| **Day 06** | AI Product Project Management | **26 câu** | 1 files | P1: 26c | `Day_06_FULL_TOAN_BO_26_CAU.xlsx` |
| **Day 07** | Data Foundations, Embedding & Vector Store | **63 câu** | 3 files | P1: 21c, P2: 21c, P3: 21c | `Day_07_FULL_TOAN_BO_63_CAU.xlsx` |
| **Day 08** | RAG Pipeline & Retrieval Evaluation | **57 câu** | 3 files | P1: 19c, P2: 19c, P3: 19c | `Day_08_FULL_TOAN_BO_57_CAU.xlsx` |
| **Day 09** | Multi-Agent & A2A Systems | **59 câu** | 3 files | P1: 20c, P2: 20c, P3: 19c | `Day_09_FULL_TOAN_BO_59_CAU.xlsx` |
| **Day 10** | Data Pipeline & Observability | **64 câu** | 3 files | P1: 22c, P2: 21c, P3: 21c | `Day_10_FULL_TOAN_BO_64_CAU.xlsx` |
| **Day 11** | Guardrails & AI Safety | **65 câu** | 3 files | P1: 22c, P2: 22c, P3: 21c | `Day_11_FULL_TOAN_BO_65_CAU.xlsx` |
| **Day 12** | Cloud Services & Deployment | **86 câu** | 4 files | P1: 22c, P2: 22c, P3: 21c, P4: 21c | `Day_12_FULL_TOAN_BO_86_CAU.xlsx` |
| **Day 13** | Monitoring, Logging & Observability | **76 câu** | 4 files | P1: 19c, P2: 19c, P3: 19c, P4: 19c | `Day_13_FULL_TOAN_BO_76_CAU.xlsx` |
| **Day 14** | AI Evaluation & Benchmarking | **74 câu** | 4 files | P1: 19c, P2: 19c, P3: 18c, P4: 18c | `Day_14_FULL_TOAN_BO_74_CAU.xlsx` |
| **Day 15** | Triển khai thực tế & Định hướng Enterprise | **68 câu** | 3 files | P1: 23c, P2: 23c, P3: 22c | `Day_15_FULL_TOAN_BO_68_CAU.xlsx` |

---

## 🚀 HƯỚNG DẪN 3 BƯỚC NẠP FILE VÀO QUIZ.COM / QUIZIZZ

### Bước 1: Chuẩn bị file
1. Mở thư mục `01_CHUAN_IMPORT_QUIZIZZ_QUIZ_COM_904_CAU/`.
2. Chọn thư mục Ngày muốn tạo đề (ví dụ `Day_01_Foundation_LLM`).
3. Chọn file muốn import:
   - Dùng file phần nếu muốn làm bài 15-20 câu (`Day_01_Phan_01_21_Cau.xlsx`).
   - Dùng file `FULL` nếu muốn nạp toàn bộ câu hỏi của ngày đó vào một bài kiểm tra lớn.

### Bước 2: Tải lên hệ thống Quiz
1. Đăng nhập vào **https://quizizz.com** hoặc **https://quiz.com/** bằng tài khoản của bạn.
2. Bấm nút **Create** (Tạo mới) -> Chọn **Quiz** (hoặc Assessment).
3. Tìm và bấm vào nút **Import from spreadsheet** (Nhập từ bảng tính Excel).
4. Kéo thả file Excel `.xlsx` đã chọn vào khung tải lên (hoặc bấm **Upload from device**).

### Bước 3: Xem trước và Xuất bản (Publish)
1. Hệ thống sẽ tự động quét toàn bộ câu hỏi:
   - Cột **Question**: Nội dung câu hỏi và bối cảnh.
   - Cột **Option 1 - 5**: Các đáp án lựa chọn A, B, C, D, E.
   - Cột **Correct Answer**: Tự động đánh dấu đáp án đúng (1, 2, 3... hoặc 1,3,5 nếu là câu hỏi chọn nhiều đáp án).
   - Cột **Time**: Đã cài đặt sẵn 60 giây cho mỗi câu.
2. Kiểm tra lại và bấm **Save / Publish** để bắt đầu tổ chức thi hoặc tự luyện!

---

## 💡 ĐẶC ĐIỂM KỸ THUẬT CỦA CÁC FILE ĐÃ TẠO
1. **Đúng 100% định dạng mẫu `samplefile.xlsx` chính thức của Quizizz**: Không phát sinh lỗi lệch cột hay thiếu trường bắt buộc.
2. **Không có câu hỏi lỗi**: Tất cả câu hỏi ghép cặp và sắp xếp quy trình đều được chuyển thành dạng trắc nghiệm đối sánh logic, giúp học viên thao tác thuận tiện trên điện thoại.
3. **Phân phối thời gian thông minh**: Mỗi câu được gán mặc định 60 giây, đảm bảo học viên đủ thời gian đọc hiểu bối cảnh kỹ thuật chuyên sâu.
